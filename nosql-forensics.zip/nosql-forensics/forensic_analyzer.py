import hashlib
from datetime import datetime
import json
import pandas as pd
from typing import Dict, List, Tuple
import os
import sqlite3

class NoSQLForensicAnalyzer:
    def __init__(self, db_path: str = "forensic_test.db"):
        """Uses SQLite to simulate MongoDB for testing"""
        self.db_path = db_path
        self._init_simulated_db()
        
    def _init_simulated_db(self):
        """Create SQLite database simulating MongoDB collections"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Simulate MongoDB 'evidence' collection
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS evidence (
                _id INTEGER PRIMARY KEY AUTOINCREMENT,
                id INTEGER,
                user TEXT,
                action TEXT,
                amount REAL,
                timestamp TEXT,
                tamper_flag BOOLEAN DEFAULT 0
            )
        ''')
        
        # Simulate oplog.rs
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS oplog (
                ts TEXT,
                op TEXT,
                ns TEXT,
                o TEXT,
                o2 TEXT
            )
        ''')
        conn.commit()
        conn.close()
    
    def inject_tamper_sample(self):
        """Create test collection with tampered data"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM evidence")
        
        # Normal data
        normal_docs = [
            (1, "alice", "login", None, datetime.now().isoformat(), 0),
            (2, "bob", "transfer", 1000, datetime.now().isoformat(), 0)
        ]
        cursor.executemany('''
            INSERT INTO evidence (id, user, action, amount, timestamp, tamper_flag) 
            VALUES (?, ?, ?, ?, ?, ?)
        ''', normal_docs)
        
        # Tampered doc (backdated timestamp)
        cursor.execute('''
            INSERT INTO evidence (id, user, action, amount, timestamp, tamper_flag) 
            VALUES (3, 'charlie', 'delete', NULL, '2026-01-01T00:00:00Z', 1)
        ''')
        
        # Simulate oplog entries
        oplog_entries = [
            (datetime.now().isoformat(), 'i', 'forensic_test.evidence', 
             json.dumps({"id": 1, "user": "alice"}), None),
            (datetime.now().isoformat(), 'i', 'forensic_test.evidence', 
             json.dumps({"id": 3, "user": "charlie"}), None)
        ]
        cursor.executemany('''
            INSERT INTO oplog (ts, op, ns, o, o2) VALUES (?, ?, ?, ?, ?)
        ''', oplog_entries)
        
        conn.commit()
        conn.close()
    
    def compute_document_hash(self, doc: Dict) -> str:
        """SHA-256 hash for integrity verification"""
        doc_str = json.dumps(doc, sort_keys=True, default=str)
        return hashlib.sha256(doc_str.encode()).hexdigest()
    
    def analyze_oplog_tampering(self) -> pd.DataFrame:
        """Parse simulated oplog for suspicious operations"""
        conn = sqlite3.connect(self.db_path)
        
        df = pd.read_sql_query('''
            SELECT ts, op, ns, o, o2 FROM oplog 
            WHERE op IN ('i', 'u', 'd') 
            ORDER BY ts DESC LIMIT 1000
        ''', conn)
        conn.close()
        
        suspicious_ops = []
        for _, row in df.iterrows():
            try:
                op_doc = json.loads(row['o']) if row['o'] else {}
                op_hash = self.compute_document_hash(op_doc)
                
                is_suspicious = (
                    'timestamp' not in op_doc or 
                    len(str(op_doc)) > 500 or
                    row['ns'] == 'forensic_test.evidence'
                )
                
                suspicious_ops.append({
                    'timestamp': row['ts'],
                    'operation': row['op'],
                    'namespace': row['ns'],
                    'doc_id': op_doc.get('id', 'N/A'),
                    'hash': op_hash,
                    'suspicious': is_suspicious,
                    'size_bytes': len(str(op_doc))
                })
            except:
                continue
        
        return pd.DataFrame(suspicious_ops)
    
    def verify_collection_integrity(self, collection_name: str = 'evidence') -> Dict:
        """Cross-verify docs against computed hashes"""
        conn = sqlite3.connect(self.db_path)
        df = pd.read_sql_query("SELECT * FROM evidence", conn)
        conn.close()
        
        results = {
            'total_docs': len(df),
            'tampered': 0,
            'hashes': {}
        }
        
        for _, doc in df.iterrows():
            doc_dict = {
                'id': doc['id'], 'user': doc['user'], 'action': doc['action'],
                'amount': doc['amount'], 'timestamp': doc['timestamp']
            }
            doc_id = doc['_id']
            expected_hash = self.compute_document_hash(doc_dict)
            results['hashes'][doc_id] = expected_hash
            
            if doc['tamper_flag']:
                results['tampered'] += 1
        
        return results

# Usage
if __name__ == "__main__":
    analyzer = NoSQLForensicAnalyzer("forensic_test.db")
    analyzer.inject_tamper_sample()
    
    # Generate forensic report
    report = analyzer.analyze_oplog_tampering()
    integrity = analyzer.verify_collection_integrity()
    
    print("OPLOG ANALYSIS:")
    suspicious_report = report[report['suspicious'] == True]
    print(suspicious_report.to_string(index=False))
    
    print(f"\nINTEGRITY CHECK: {integrity['tampered']}/{integrity['total_docs']} tampered")
    print("Hashes:", list(integrity['hashes'].items())[:3])
