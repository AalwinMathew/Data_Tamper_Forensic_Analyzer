import streamlit as st
import pandas as pd
import hashlib
import sqlite3
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go
import io
import time
import numpy as np

st.set_page_config(
    page_title="Data Tamper Forensic Analyzer",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

class DataTamperForensicAnalyzer:
    def __init__(self, db_path="tamper_evidence.db"):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS evidence (
                _id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT,
                row_data TEXT,
                row_hash TEXT,
                timestamp TEXT,
                column_count INTEGER,
                row_index INTEGER,
                tamper_flag INTEGER DEFAULT 0,
                suspicious_keywords TEXT
            )
        ''')
        conn.commit()
        conn.close()
    
    def inject_sample_data(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM evidence")

        now = datetime.now().isoformat()
        samples = [
            ("file1.csv", "id:1,user:admin,action:login", now, 3, 0, 0, ""),
            ("file1.csv", "id:2,user:admin,action:delete", now, 3, 1, 1, "delete"),
            ("file1.csv", "id:3,user:guest,action:transfer,amount:999999", now, 4, 2, 1, "transfer,999999"),
            ("file2.csv", "id:4,user:user1,action:view", now, 3, 0, 0, ""),
            ("file2.csv", "id:5,user:admin,action:update", now, 4, 1, 1, "admin"),
            ("file3.csv", "id:6,user:root,action:drop", now, 3, 0, 1, "root,drop"),
        ]

        cursor.executemany("""
            INSERT INTO evidence 
            (filename, row_data, timestamp, column_count, row_index, tamper_flag, suspicious_keywords)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, samples)
        conn.commit()
        conn.close()
    
    def analyze_csv_row(self, row, filename: str, row_index: int):
        row_str = ' | '.join([str(x) for x in row.values if pd.notna(x)])
        row_hash = hashlib.sha256(row_str.encode()).hexdigest()

        keywords = ['delete', 'drop', 'remove', 'error', 'failed', 'suspicious', 'admin', 'root']
        suspicious = [kw for kw in keywords if kw in row_str.lower()]
        tamper_flag = 1 if suspicious or any(str(x).startswith('9') for x in row.values if pd.notna(x)) else 0

        return {
            'filename': filename,
            'row_data': row_str[:1000],
            'row_hash': row_hash,
            'timestamp': str(pd.Timestamp.now()),
            'column_count': len(row),
            'row_index': row_index,
            'tamper_flag': tamper_flag,
            'suspicious_keywords': ','.join(suspicious)
        }
    
    def scan_csv_files(self, uploaded_files):
        total_records = 0

        for i, uploaded_file in enumerate(uploaded_files):
            st.session_state.scan_progress = (i + 1) / len(uploaded_files)
            st.progress(st.session_state.scan_progress)

            filename = uploaded_file.name
            st.info(f"🔍 **{filename}**")

            try:
                uploaded_file.seek(0)
                file_content = uploaded_file.read()
                df = pd.read_csv(io.StringIO(file_content.decode('utf-8')))

                records = []
                for row_idx, row in df.iterrows():
                    record = self.analyze_csv_row(row, filename, row_idx)
                    records.append(record)

                conn = sqlite3.connect(self.db_path)
                cursor = conn.cursor()
                for record in records:
                    cursor.execute("""
                        INSERT INTO evidence 
                        (filename, row_data, row_hash, timestamp, column_count, 
                         row_index, tamper_flag, suspicious_keywords)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        record['filename'], record['row_data'], record['row_hash'],
                        record['timestamp'], record['column_count'], record['row_index'],
                        record['tamper_flag'], record['suspicious_keywords']
                    ))
                conn.commit()
                conn.close()

                total_records += len(records)
                st.success(f"✅ **{len(records)}** rows analyzed")

            except Exception as e:
                st.error(f"❌ {filename}: {e}")
                continue

        st.session_state.data_loaded = True
        return total_records
    
    def get_analysis(self):
        conn = sqlite3.connect(self.db_path)
        df = pd.read_sql_query('SELECT * FROM evidence ORDER BY timestamp DESC LIMIT 500', conn)
        conn.close()
        return df
    
    def clear_all_data(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM evidence")
        conn.commit()
        conn.close()

# Initialize
if 'analyzer' not in st.session_state:
    st.session_state.analyzer = DataTamperForensicAnalyzer()
    st.session_state.scan_progress = 0

st.title("🔍 Data Tamper Forensic Analyzer")
st.markdown("**Professional CSV data integrity analysis & tamper detection**")

# Upload - CSV ONLY
st.header("📁 Data Integrity Analysis")
col1, col2 = st.columns([3, 1])

with col1:
    uploaded_files = st.file_uploader(
        "Upload CSV files for tamper analysis",
        accept_multiple_files=True,
        type=['csv']
    )

with col2:
    st.markdown("""
    **✅ Forensic Features:**
    • SHA256 row hashing
    • Tamper detection
    • Suspicious keyword scan
    • Data integrity verification
    """)

# SCAN BUTTON
if uploaded_files:
    if st.button(f"🚀 **DATA TAMPER SCAN {len(uploaded_files)} CSV{'S' if len(uploaded_files) > 1 else ''}**",
                type="primary", use_container_width=True):

        with st.spinner("🔍 Analyzing data integrity..."):
            total_records = st.session_state.analyzer.scan_csv_files(uploaded_files)

        st.success(f"🎉 **{total_records}** rows forensically analyzed!")
        st.balloons()
        st.rerun()

# Progress bar
if 0 < st.session_state.scan_progress < 1:
    st.header("🔄 TAMPER SCAN IN PROGRESS...")
    st.progress(st.session_state.scan_progress)
    st.info(f"**{int(st.session_state.scan_progress*100)}%** complete")

# Sidebar
with st.sidebar:
    st.header("⚡ Forensic Controls")
    if st.button("💾 Load Demo Data", use_container_width=True):
        st.session_state.analyzer.inject_sample_data()
        st.rerun()
    if st.button("🗑️ Clear Evidence DB", use_container_width=True):
        st.session_state.analyzer.clear_all_data()
        st.rerun()

# Results Dashboard - FIXED AREA PROJECTIONS
df = st.session_state.analyzer.get_analysis()
if len(df) > 0:
    st.header("📊 Tamper Analysis Results")

    col1, col2 = st.columns([2, 1])

    with col1:
        # Metrics
        c1, c2, c3, c4 = st.columns(4)
        with c1: st.metric("Total Rows", len(df))
        with c2: st.metric("🚨 Tampered", len(df[df.tamper_flag == 1]))
        with c3: st.metric("Files", df.filename.nunique())
        with c4: st.metric("Avg Columns", int(df.column_count.mean()))

        # 🎯 FIXED AREA GRAPH 1: Cumulative Rows by File (with projection)
        st.subheader("📈 Data Volume Projection")
        file_data = df.groupby(['filename', 'row_index']).size().reset_index(name='count')
        file_data['cumulative'] = file_data.groupby('filename')['count'].cumsum()
        
        fig1 = px.area(file_data, x='row_index', y='cumulative', 
                      color='filename',
                      title="📊 Cumulative Data Volume by Row (Area Projection)",
                      labels={'cumulative': 'Cumulative Rows', 'row_index': 'Row Index'})
        fig1.update_traces(fill='tonexty')
        fig1.update_layout(showlegend=True, height=400)
        st.plotly_chart(fig1, use_container_width=True)

        # 🎯 FIXED AREA GRAPH 2: Tamper Trend Projection
        st.subheader("🚨 Tamper Risk Projection")
        df['row_num'] = range(len(df))
        tamper_trend = df.groupby(['row_num', 'tamper_flag']).size().unstack(fill_value=0)
        if tamper_trend.empty:
            tamper_trend[0] = 0
            tamper_trend[1] = 0
        
        fig2 = go.Figure()
        fig2.add_trace(go.Scatter(x=tamper_trend.index, y=tamper_trend.get(0, [0]*len(tamper_trend.index)).cumsum(),
                                 fill='tonexty', name='Clean Rows', line=dict(color='green')))
        fig2.add_trace(go.Scatter(x=tamper_trend.index, y=tamper_trend.get(1, [0]*len(tamper_trend.index)).cumsum(),
                                 fill='tonexty', name='🚨 Tampered Rows', line=dict(color='red')))
        fig2.update_layout(title="Tamper Trend Over Rows (Area Projection)",
                          xaxis_title="Row Number", yaxis_title="Cumulative Count",
                          height=400)
        st.plotly_chart(fig2, use_container_width=True)

    with col2:
        st.subheader("🔍 Recent Data Rows")
        display_cols = ['filename', 'row_index', 'tamper_flag', 'suspicious_keywords']
        st.dataframe(df[display_cols].head(20), use_container_width=True)

        st.subheader("🚨 Tampered Rows")
        suspicious = df[df.tamper_flag == 1][['filename', 'row_data', 'suspicious_keywords']].head(10)
        if len(suspicious) > 0:
            for _, row in suspicious.iterrows():
                with st.expander(f"**{row['filename']}** - Row {row.get('row_index', 'N/A')}"):
                    st.write(row['row_data'])
                    st.warning(f"🚨 Keywords: {row['suspicious_keywords']}")
        else:
            st.success("✅ No data tampering detected")

else:
    st.info("👆 **Upload CSV files → SCAN → Tamper analysis instantly!**")

    st.markdown("---")
    st.markdown("""
    **💡 Test CSV format:**
    ```csv
    id,user,action,amount
    1,admin,login,
    2,admin,delete,
    3,guest,transfer,999999
    ```
    """)
