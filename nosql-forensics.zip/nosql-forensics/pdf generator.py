from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak, Image
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from datetime import datetime
import os

class PDFDocumentationGenerator:
    def __init__(self, filename="Data_Tamper_Forensic_Analyzer_Documentation.pdf"):
        self.filename = filename
        self.doc = SimpleDocTemplate(filename, pagesize=A4,
                                    rightMargin=0.5*inch, leftMargin=0.5*inch,
                                    topMargin=0.75*inch, bottomMargin=0.75*inch)
        self.story = []
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1f77b4'),
            spaceAfter=30,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        self.heading_style = ParagraphStyle(
            'CustomHeading',
            parent=self.styles['Heading2'],
            fontSize=14,
            textColor=colors.HexColor('#d62728'),
            spaceAfter=12,
            spaceBefore=12,
            fontName='Helvetica-Bold'
        )
        
        self.normal_style = ParagraphStyle(
            'CustomNormal',
            parent=self.styles['BodyText'],
            fontSize=10,
            alignment=TA_JUSTIFY,
            spaceAfter=12
        )
    
    def add_title_page(self):
        """Add title page"""
        self.story.append(Spacer(1, 1.5*inch))
        
        title = Paragraph("🔍 Data Tamper Forensic Analyzer", self.title_style)
        self.story.append(title)
        self.story.append(Spacer(1, 0.3*inch))
        
        subtitle = Paragraph("<b>Complete Technical Documentation</b>", self.styles['Heading3'])
        self.story.append(subtitle)
        self.story.append(Spacer(1, 0.2*inch))
        
        version = Paragraph(f"<b>Version:</b> 1.0.0 | <b>Date:</b> {datetime.now().strftime('%B %d, %Y')}", 
                           self.styles['Normal'])
        self.story.append(version)
        self.story.append(Spacer(1, 1*inch))
        
        description = Paragraph(
            "A professional-grade CSV data integrity analysis and tamper detection tool "
            "built with Python, Streamlit, and SQLite. This application provides forensic-level "
            "analysis of CSV files to detect data tampering, suspicious patterns, and integrity violations.",
            self.normal_style
        )
        self.story.append(description)
        self.story.append(PageBreak())
    
    def add_table_of_contents(self):
        """Add table of contents"""
        title = Paragraph("Table of Contents", self.heading_style)
        self.story.append(title)
        self.story.append(Spacer(1, 0.2*inch))
        
        toc_items = [
            "1. Introduction",
            "2. Features & Capabilities",
            "3. System Requirements",
            "4. Installation Guide",
            "5. Usage Instructions",
            "6. Architecture & Design",
            "7. Database Schema",
            "8. Forensic Analysis Methods",
            "9. API Reference",
            "10. Troubleshooting",
            "11. FAQ",
            "12. Support & Contact"
        ]
        
        for item in toc_items:
            self.story.append(Paragraph(item, self.styles['Normal']))
            self.story.append(Spacer(1, 0.1*inch))
        
        self.story.append(PageBreak())
    
    def add_introduction(self):
        """Add introduction section"""
        title = Paragraph("1. Introduction", self.heading_style)
        self.story.append(title)
        
        content = """
        The <b>Data Tamper Forensic Analyzer</b> is an advanced forensic analysis tool designed to detect 
        and document data tampering, manipulation, and integrity violations in CSV files. Using SHA256 hashing, 
        keyword detection algorithms, and statistical analysis, this tool provides enterprise-grade forensic 
        capabilities for digital investigators, compliance officers, and data governance teams.
        <br/><br/>
        <b>Key Objectives:</b>
        <br/>• Detect suspicious data modifications and unauthorized changes
        <br/>• Generate forensic evidence reports with cryptographic hashing
        <br/>• Identify anomalous patterns in data fields
        <br/>• Maintain audit trails and evidence preservation
        <br/>• Support compliance with regulatory requirements (GDPR, HIPAA, SOX)
        """
        self.story.append(Paragraph(content, self.normal_style))
        self.story.append(Spacer(1, 0.3*inch))
        self.story.append(PageBreak())
    
    def add_features(self):
        """Add features section"""
        title = Paragraph("2. Features & Capabilities", self.heading_style)
        self.story.append(title)
        
        features = [
            ("Cryptographic Hashing", "SHA256 hashing for each row to detect modifications"),
            ("Tamper Detection", "Automatic flagging of suspicious keywords and patterns"),
            ("Keyword Analysis", "Detects: delete, drop, error, failed, suspicious, admin, root"),
            ("Statistical Analysis", "Column analysis, distribution patterns, anomaly detection"),
            ("Real-time Scanning", "Process multiple CSV files simultaneously"),
            ("Interactive Dashboard", "Plotly-based visualizations with area projections"),
            ("SQLite Integration", "Persistent evidence storage and retrieval"),
            ("Forensic Reports", "Generate detailed analysis reports"),
            ("Multi-file Support", "Batch processing of multiple CSV files"),
            ("Export Capabilities", "Data export for further analysis")
        ]
        
        for feature, description in features:
            content = f"<b>✓ {feature}:</b> {description}"
            self.story.append(Paragraph(content, self.normal_style))
            self.story.append(Spacer(1, 0.1*inch))
        
        self.story.append(PageBreak())
    
    def add_requirements(self):
        """Add system requirements"""
        title = Paragraph("3. System Requirements", self.heading_style)
        self.story.append(title)
        
        requirements = [
            ("Operating System", "Windows 10+, macOS 10.14+, Linux (Ubuntu 18.04+)"),
            ("Python Version", "Python 3.8 or higher"),
            ("RAM", "Minimum 2GB, Recommended 4GB+"),
            ("Storage", "Minimum 100MB for installation"),
            ("Internet", "Required for initial installation only")
        ]
        
        table_data = [["Requirement", "Specification"]] + requirements
        table = Table(table_data, colWidths=[1.5*inch, 4*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1f77b4')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 11),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        self.story.append(table)
        self.story.append(Spacer(1, 0.3*inch))
        self.story.append(PageBreak())
    
    def add_installation(self):
        """Add installation guide"""
        title = Paragraph("4. Installation Guide", self.heading_style)
        self.story.append(title)
        
        steps = [
            ("Step 1: Clone Repository", "git clone https://github.com/your-repo/forensic-analyzer.git<br/>cd forensic-analyzer"),
            ("Step 2: Create Virtual Environment", "python -m venv venv<br/>source venv/bin/activate  # On Windows: venv\\Scripts\\activate"),
            ("Step 3: Install Dependencies", "pip install -r requirements.txt"),
            ("Step 4: Run Application", "python -m streamlit run forensic_dashboard.py")
        ]
        
        for step, command in steps:
            content = f"<b>{step}</b><br/><font face='Courier'>{command}</font>"
            self.story.append(Paragraph(content, self.normal_style))
            self.story.append(Spacer(1, 0.15*inch))
        
        self.story.append(Spacer(1, 0.2*inch))
        req_title = Paragraph("<b>Required Dependencies:</b>", self.normal_style)
        self.story.append(req_title)
        
        deps = ["streamlit>=1.0.0", "pandas>=1.3.0", "plotly>=5.0.0", "reportlab>=3.6.0"]
        for dep in deps:
            self.story.append(Paragraph(f"• {dep}", self.normal_style))
        
        self.story.append(PageBreak())
    
    def add_usage(self):
        """Add usage instructions"""
        title = Paragraph("5. Usage Instructions", self.heading_style)
        self.story.append(title)
        
        usage_steps = """
        <b>Step-by-Step Guide:</b>
        <br/><br/>
        <b>1. Launch Application</b>
        <br/>Run the command: <font face='Courier'>streamlit run forensic_dashboard.py</font>
        <br/>The application opens in your default web browser at <font face='Courier'>http://localhost:8501</font>
        <br/><br/>
        
        <b>2. Upload CSV Files</b>
        <br/>Click "Upload CSV files for tamper analysis" and select one or multiple CSV files
        <br/>Supported formats: Standard CSV with headers
        <br/><br/>
        
        <b>3. Initiate Forensic Scan</b>
        <br/>Click the "🚀 DATA TAMPER SCAN" button to begin analysis
        <br/>Progress indicator shows real-time scanning status
        <br/><br/>
        
        <b>4. Review Results</b>
        <br/>• View metrics: Total rows, tampered count, file count
        <br/>• Analyze area projections showing data volume trends
        <br/>• Examine tamper risk profiles
        <br/>• Inspect detailed row-level evidence
        <br/><br/>
        
        <b>5. Export Evidence</b>
        <br/>Download forensic reports and evidence for legal proceedings
        """
        self.story.append(Paragraph(usage_steps, self.normal_style))
        self.story.append(PageBreak())
    
    def add_architecture(self):
        """Add architecture section"""
        title = Paragraph("6. Architecture & Design", self.heading_style)
        self.story.append(title)
        
        architecture = """
        <b>System Architecture:</b>
        <br/><br/>
        The application follows a three-tier architecture:
        <br/><br/>
        <b>Tier 1: Presentation Layer (Streamlit)</b>
        <br/>• Interactive web interface
        <br/>• Real-time data visualization
        <br/>• User input handling
        <br/><br/>
        
        <b>Tier 2: Business Logic Layer (Python)</b>
        <br/>• CSV file parsing and validation
        <br/>• SHA256 cryptographic hashing
        <br/>• Tamper detection algorithms
        <br/>• Statistical analysis
        <br/><br/>
        
        <b>Tier 3: Data Persistence Layer (SQLite)</b>
        <br/>• Evidence storage in relational database
        <br/>• Timestamp tracking
        <br/>• Query optimization
        <br/>• Data integrity maintenance
        <br/><br/>
        
        <b>Key Classes:</b>
        <br/>• DataTamperForensicAnalyzer: Main analysis engine
        <br/>• Evidence: Data model for forensic records
        <br/>• ForensicHash: Cryptographic operations
        """
        self.story.append(Paragraph(architecture, self.normal_style))
        self.story.append(PageBreak())
    
    def add_database_schema(self):
        """Add database schema"""
        title = Paragraph("7. Database Schema", self.heading_style)
        self.story.append(title)
        
        schema_text = """
        <b>Primary Table: Evidence</b>
        <br/><br/>
        The evidence table stores forensic analysis records:
        """
        self.story.append(Paragraph(schema_text, self.normal_style))
        self.story.append(Spacer(1, 0.2*inch))
        
        schema_data = [
            ["Column", "Type", "Description"],
            ["_id", "INTEGER PK", "Unique evidence record identifier"],
            ["filename", "TEXT", "Source CSV filename"],
            ["row_data", "TEXT", "Row content (max 1000 chars)"],
            ["row_hash", "TEXT", "SHA256 cryptographic hash"],
            ["timestamp", "TEXT", "Analysis timestamp"],
            ["column_count", "INTEGER", "Number of columns in row"],
            ["row_index", "INTEGER", "Row position in CSV"],
            ["tamper_flag", "INTEGER", "1=Suspicious, 0=Clean"],
            ["suspicious_keywords", "TEXT", "Detected suspicious keywords"]
        ]
        
        table = Table(schema_data, colWidths=[1.2*inch, 1.2*inch, 3.1*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#d62728')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey])
        ]))
        self.story.append(table)
        self.story.append(PageBreak())
    
    def add_forensic_methods(self):
        """Add forensic methods"""
        title = Paragraph("8. Forensic Analysis Methods", self.heading_style)
        self.story.append(title)
        
        methods = """
        <b>Hash-Based Integrity Verification:</b>
        <br/>SHA256 cryptographic hashing provides:
        <br/>• Unique fingerprint for each data row
        <br/>• Detection of even single-character modifications
        <br/>• Proof of data authenticity
        <br/>• Compliance with forensic standards
        <br/><br/>
        
        <b>Keyword-Based Anomaly Detection:</b>
        <br/>Suspicious keywords trigger tamper flags:
        <br/>• delete, drop, remove: Data deletion indicators
        <br/>• error, failed: System failure indicators
        <br/>• admin, root: Privilege escalation indicators
        <br/>• suspicious: User-marked suspicious entries
        <br/><br/>
        
        <b>Pattern-Based Analysis:</b>
        <br/>• Detects numeric anomalies (999999+ values)
        <br/>• Identifies unusual column distributions
        <br/>• Tracks cumulative data trends
        <br/>• Statistical outlier detection
        <br/><br/>
        
        <b>Temporal Analysis:</b>
        <br/>• Timestamp-based evidence tracking
        <br/>• Chronological anomaly detection
        <br/>• Timeline reconstruction
        <br/>• Event sequencing
        """
        self.story.append(Paragraph(methods, self.normal_style))
        self.story.append(PageBreak())
    
    def add_troubleshooting(self):
        """Add troubleshooting section"""
        title = Paragraph("10. Troubleshooting", self.heading_style)
        self.story.append(title)
        
        issues = [
            ("CSV file not loading", "Ensure CSV has headers in first row. Check encoding is UTF-8."),
            ("Slow performance", "Large files (>100K rows) may take longer. Process in batches."),
            ("Database locked", "Close other instances. Delete forensic_evidence.db and restart."),
            ("Memory errors", "Reduce CSV file size. Increase system RAM if persistent."),
            ("Port already in use", "Run: streamlit run forensic_dashboard.py --server.port 8502")
        ]
        
        for issue, solution in issues:
            content = f"<b>Q: {issue}</b><br/><b>A:</b> {solution}"
            self.story.append(Paragraph(content, self.normal_style))
            self.story.append(Spacer(1, 0.15*inch))
        
        self.story.append(PageBreak())
    
    def add_faq(self):
        """Add FAQ section"""
        title = Paragraph("11. FAQ", self.heading_style)
        self.story.append(title)
        
        faqs = [
            ("What file formats are supported?", "Currently CSV files. JSON and Excel support planned."),
            ("Is the analysis legally defensible?", "Yes. SHA256 hashing and detailed logging provide forensic-grade evidence."),
            ("Can I export forensic reports?", "Yes. PDF and CSV export functionality available."),
            ("How long does scanning take?", "Typically 1-5 seconds per 1000 rows depending on hardware."),
            ("Is my data secure?", "Data stored locally in SQLite. No cloud transmission. Full control over storage.")
        ]
        
        for q, a in faqs:
            content = f"<b>Q: {q}</b><br/>{a}"
            self.story.append(Paragraph(content, self.normal_style))
            self.story.append(Spacer(1, 0.15*inch))
        
        self.story.append(PageBreak())
    
    def add_contact(self):
        """Add contact and support"""
        title = Paragraph("12. Support & Contact", self.heading_style)
        self.story.append(title)
        
        contact = """
        <b>Documentation & Resources:</b>
        <br/>• GitHub Repository: https://github.com/your-org/forensic-analyzer
        <br/>• Issues & Bug Reports: GitHub Issues
        <br/>• Feature Requests: GitHub Discussions
        <br/><br/>
        
        <b>Version History:</b>
        <br/><b>v1.0.0</b> (Current) - Initial release with core forensic features
        <br/>• CSV file analysis
        <br/>• SHA256 hashing
        <br/>• Real-time visualization
        <br/>• SQLite storage
        <br/><br/>
        
        <b>License:</b>
        <br/>This software is proprietary. All rights reserved.
        <br/>Unauthorized copying is prohibited.
        <br/><br/>
        
        <b>Disclaimer:</b>
        <br/>This tool is designed for authorized forensic investigation only. 
        Users are responsible for compliance with applicable laws and regulations.
        """
        self.story.append(Paragraph(contact, self.normal_style))
    
    def generate(self):
        """Generate PDF document"""
        self.add_title_page()
        self.add_table_of_contents()
        self.add_introduction()
        self.add_features()
        self.add_requirements()
        self.add_installation()
        self.add_usage()
        self.add_architecture()
        self.add_database_schema()
        self.add_forensic_methods()
        self.add_troubleshooting()
        self.add_faq()
        self.add_contact()
        
        self.doc.build(self.story)
        return self.filename

# Generate documentation
if __name__ == "__main__":
    generator = PDFDocumentationGenerator()
    pdf_file = generator.generate()
    print(f"✅ PDF Documentation generated: {pdf_file}")
