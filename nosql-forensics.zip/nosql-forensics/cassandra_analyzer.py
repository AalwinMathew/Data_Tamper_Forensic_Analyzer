import re
import struct
import os
from datetime import datetime
from typing import List, Dict
import logging

class CassandraForensicAnalyzer:
    def __init__(self, cassandra_home: str = "/var/lib/cassandra"):
        self.cassandra_home = cassandra_home
        self.commitlog_dir = os.path.join(cassandra_home, "commitlog")
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def find_commitlogs(self) -> List[str]:
        """Locate Cassandra commitlog files"""
        if not os.path.exists(self.commitlog_dir):
            # Default locations for different OS
            possible_dirs = [
                "/var/lib/cassandra/commitlog",
                "C:/Program Files/Apache Cassandra/commitlog",
                "./data/commitlog"  # Docker/development
            ]
            for d in possible_dirs:
                if os.path.exists(d):
                    self.commitlog_dir = d
                    break
        
        commitlogs = []
        if os.path.exists(self.commitlog_dir):
            commitlogs = [os.path.join(self.commitlog_dir, f) for f in os.listdir(self.commitlog_dir) 
                         if f.endswith('.log')]
        return commitlogs
    
    def parse_commitlog_binary(self, log_path: str) -> List[Dict]:
        """Parse Cassandra commitlog binary format directly"""
        mutations = []
        
        try:
            with open(log_path, 'rb') as f:
                # Cassandra commitlog format: https://cwiki.apache.org/confluence/display/CASSANDRA2/CommitLog+Format
                data = f.read()
                offset = 0
                
                while offset < len(data):
                    # Read sync marker (8 bytes)
                    if offset + 8 > len(data):
                        break
                    sync_marker = struct.unpack('>Q', data[offset:offset+8])[0]
                    
                    # Skip sync section (header + checksum)
                    offset += 28  # Fixed header size
                    
                    if offset + 4 > len(data):
                        break
                    
                    # Read mutation length
                    mutation_len = struct.unpack('>I', data[offset:offset+4])[0]
                    offset += 4
                    
                    if offset + mutation_len > len(data):
                        break
                    
                    # Extract mutation data
                    mutation_data = data[offset:offset + mutation_len]
                    
                    # Basic mutation parsing (keyspace.table.operation)
                    try:
                        # Look for recognizable patterns in mutation
                        mutation_str = mutation_data[:200].decode('utf-8', errors='ignore')
                        
                        mutations.append({
                            'filename': os.path.basename(log_path),
                            'offset': offset,
                            'timestamp': datetime.now().isoformat(),
                            'mutation_length': mutation_len,
                            'operation': self._classify_mutation(mutation_str),
                            'keyspace_table': self._extract_keyspace(mutation_str),
                            'payload_preview': mutation_str[:100],
                            'raw_bytes': len(mutation_data)
                        })
                    except:
                        pass
                    
                    offset += mutation_len
                
        except Exception as e:
            self.logger.error(f"Error parsing {log_path}: {e}")
        
        return mutations
    
    def _classify_mutation(self, data: str) -> str:
        """Classify mutation type from binary preview"""
        data_lower = data.lower()
        if 'insert' in data_lower or b'INSERT' in data:
            return 'INSERT'
        elif 'update' in data_lower or b'UPDATE' in data:
            return 'UPDATE'
        elif 'delete' in data_lower or b'DELETE' in data:
            return 'DELETE'
        return 'MUTATION'
    
    def _extract_keyspace(self, data: str) -> str:
        """Extract keyspace.table from mutation"""
        # Common patterns: keyspace.table
        match = re.search(r'([a-zA-Z0-9_]+)\.([a-zA-Z0-9_]+)', data)
        return match.group(0) if match else 'unknown'
    
    def analyze_commitlogs(self) -> Dict:
        """Full forensic analysis of all commitlogs"""
        commitlogs = self.find_commitlogs()
        all_mutations = []
        
        for log_path in commitlogs:
            self.logger.info(f"Analyzing {log_path}")
            mutations = self.parse_commitlog_binary(log_path)
            all_mutations.extend(mutations)
        
        # Anomaly detection
        anomalies = self.detect_anomalies(all_mutations)
        
        return {
            'commitlog_files': len(commitlogs),
            'total_mutations': len(all_mutations),
            'anomalies': anomalies,
            'recent_mutations': all_mutations[-10:] if all_mutations else [],
            'files_analyzed': commitlogs
        }
    
    def detect_anomalies(self, mutations: List[Dict]) -> Dict:
        """Flag suspicious commitlog activity"""
        anomalies = []
        
        for mutation in mutations:
            is_anomalous = (
                mutation['mutation_length'] > 10000 or  # Large mutations
                mutation['operation'] == 'DELETE' or     # Deletes are suspicious
                'system' not in mutation['keyspace_table']  # Non-system activity
            )
            
            if is_anomalous:
                anomalies.append(mutation)
        
        return {
            'count': len(anomalies),
            'large_mutations': len([m for m in anomalies if m['mutation_length'] > 10000]),
            'deletes': len([m for m in anomalies if m['operation'] == 'DELETE']),
            'samples': anomalies[:5]
        }

# Usage example
if __name__ == "__main__":
    analyzer = CassandraForensicAnalyzer()
    report = analyzer.analyze_commitlogs()
    
    print("CASSANDRA COMMITLOG FORENSIC ANALYSIS")
    print(f"Files analyzed: {report['commitlog_files']}")
    print(f"Total mutations: {report['total_mutations']}")
    print(f"Anomalies detected: {report['anomalies']['count']}")
    
    if report['anomalies']['samples']:
        print("\nSuspicious mutations:")
        for anomaly in report['anomalies']['samples']:
            print(f"  - {anomaly['operation']} in {anomaly['keyspace_table']} "
                  f"(size: {anomaly['mutation_length']} bytes)")
