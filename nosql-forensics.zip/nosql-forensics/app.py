from flask import Flask, render_template, jsonify
from forensic_analyzer import NoSQLForensicAnalyzer
import pandas as pd

app = Flask(__name__)
analyzer = NoSQLForensicAnalyzer()

@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/oplog')
def oplog_api():
    report = analyzer.analyze_oplog_tampering()
    suspicious = report[report['suspicious'] == True].to_dict('records')
    return jsonify({'suspicious': suspicious, 'total': len(report)})

@app.route('/api/integrity/<collection>')
def integrity_api(collection):
    integrity = analyzer.verify_collection_integrity(collection)
    return jsonify(integrity)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
